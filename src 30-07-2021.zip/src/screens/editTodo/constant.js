export const EDIT_TODO_CONST = {
  BACK_BUTTON: "< Back",
  TITLE: "Title",
  TITLE_SMALL: "title",
  DESC: "Description",
  DESC_SMALL: "description",
  SAVE: "Save",
  ADD_NEW_TASK: "Add new task",
  EDIT_TASK: "Edit task",
};
