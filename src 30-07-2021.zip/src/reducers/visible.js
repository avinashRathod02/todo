const visible = (state = "SHOW_ALL", action) => {
    return state
}
export default visible