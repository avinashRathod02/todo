export const ADD_FORM_CONST = {
  BACK_BUTTON: "< Back",
  TITLE: "Title",
  TITLE_SMALL: "title",
  DESC: "Description",
  DESC_SMALL: "desc",
  ADD: "Add",
  EDIT: "Edit",
  ADD_NEW_TASK: "Add new task",
  EDIT_TASK: "Edit task",
  REQ_ERROR_TITLE: "Title is required !",
  REQ_ERROR_DESC: "Description is required !",
};
