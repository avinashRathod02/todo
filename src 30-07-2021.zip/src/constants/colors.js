export const COLOR_CONT = {
  WHITE: "white",
  BLACK: "black",
  GRAY: "gray",
  GREEN: "green",
  RED: "red",
  TRANSPARENT: "transparent",
};
