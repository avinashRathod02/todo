export const ROUTE_CONT = {
  TODOS: "todos",
  EDITTODO: "editTodo",
  INITIAL: "todos",
};
