export const TODOS_CONST = {
  BACK_BUTTON: "< Back",
  TITLE: "Title",
  EDIT: "✏️",
  DELETE: "❌",
  COMPLETE: "✅",
  ADD_NEW_TASK: "+ Add new task",
};
