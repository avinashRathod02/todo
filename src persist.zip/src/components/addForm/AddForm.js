import React from "react";
import { reduxForm, Field } from "redux-form";
import { ScrollView, Text, TouchableOpacity } from "react-native";
import InputField from "../InputField";
import styles from "./styles";
class AddForm extends React.Component {
  render() {
    const { handleSubmit } = this.props;

    return (
      <ScrollView
        style={styles.container}
        keyboardShouldPersistTaps={"handled"}
      >
        <Text style={{ fontWeight: "bold", marginTop: 20 }}>Title :</Text>
        <Field name={"title"} component={InputField} placeholder={"Title"} />
        <Text style={{ fontWeight: "bold", marginTop: 20 }}>Description</Text>
        <Field
          name={"desc"}
          component={InputField}
          placeholder={"Description"}
          multiline={true}
          numberOfLines={4}
        />
        <TouchableOpacity
          onPress={() => {
            handleSubmit();
          }}
        >
          <Text style={styles.formSubmit}>Submit!</Text>
        </TouchableOpacity>
      </ScrollView>
    );
  }
}

export default reduxForm({
  form: "signIn",
})(AddForm);
