import { createStore, applyMiddlewares } from "redux";
import rootReducer from "../reducers";
import { persistStore, persistReducer } from "redux-persist";
import storage from "redux-persist/lib/storage";
// import AsyncStorage from "@react-native-community/async-storage";
import AsyncStorage from "react-native";
import logger from "react-logger";
import thunk from "redux-thunk";

const persistConfig = {
  key: "root",
  storage: AsyncStorage,
  whitelist: ["todos"],
};
const persistedReducer = persistReducer(persistConfig, rootReducer);

export const store: any = createStore(
  persistedReducer,
  applyMiddlewares(logger, thunk)
);
export const persistor = persistStore(store);
